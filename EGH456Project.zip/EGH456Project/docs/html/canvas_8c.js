var canvas_8c =
[
    [ "CanvasInit", "group__canvas__api.html#gaf59babcbdff898d98d11cb7be379cab2", null ],
    [ "CanvasMsgProc", "group__canvas__api.html#gaf729f2dd16f18ccdf4b6f4d4a8bd890b", null ]
];