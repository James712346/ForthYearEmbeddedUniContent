var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "gui.c", "gui_8c.html", "gui_8c" ],
    [ "gui_display.c", "gui__display_8c.html", "gui__display_8c" ],
    [ "gui_widgets.c", "gui__widgets_8c.html", "gui__widgets_8c" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "motors.c", "motors_8c.html", "motors_8c" ],
    [ "sensors.c", "sensors_8c.html", "sensors_8c" ],
    [ "shared.c", "shared_8c.html", "shared_8c" ],
    [ "startup_gcc.c", "startup__gcc_8c.html", "startup__gcc_8c" ]
];