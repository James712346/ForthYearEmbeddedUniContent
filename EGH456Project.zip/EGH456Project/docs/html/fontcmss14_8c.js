var fontcmss14_8c =
[
    [ "g_sFontCmss14", "group__primitives__api.html#gae75f09bb1f71984b41a5733c291fe887", null ]
];