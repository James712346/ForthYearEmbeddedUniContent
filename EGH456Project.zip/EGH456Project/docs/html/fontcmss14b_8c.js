var fontcmss14b_8c =
[
    [ "g_sFontCmss14b", "group__primitives__api.html#ga229e3b90c1b02b2a0d86ec9c0870e9b0", null ]
];