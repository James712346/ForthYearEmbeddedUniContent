var fontcmss20i_8c =
[
    [ "g_sFontCmss20i", "group__primitives__api.html#ga719f8daf40fd6f0aa4cb5b938557daba", null ]
];