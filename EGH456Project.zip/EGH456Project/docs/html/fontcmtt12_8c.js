var fontcmtt12_8c =
[
    [ "g_sFontCmtt12", "group__primitives__api.html#gaaac144c731d46e21bc4fc77524b3fa21", null ]
];