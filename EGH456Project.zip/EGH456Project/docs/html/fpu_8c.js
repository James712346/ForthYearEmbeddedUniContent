var fpu_8c =
[
    [ "FPUDisable", "group__fpu__api.html#ga8b93730b1be71a6c5a6c664d343d44f1", null ],
    [ "FPUEnable", "group__fpu__api.html#ga0ffddb189b5bae534eb10ca3f26f5cf6", null ],
    [ "FPUFlushToZeroModeSet", "group__fpu__api.html#ga499847e7eeb2f8cc3218e756af2a1b76", null ],
    [ "FPUHalfPrecisionModeSet", "group__fpu__api.html#ga4a606714f2a2bc58612ab133df69dba1", null ],
    [ "FPULazyStackingEnable", "group__fpu__api.html#ga9e516654e59027c539d1b11d51f4abef", null ],
    [ "FPUNaNModeSet", "group__fpu__api.html#ga4f6ab811a2066548e4a1560f7ba90865", null ],
    [ "FPURoundingModeSet", "group__fpu__api.html#gada438a50a08c4a9d599e6d0f3613907f", null ],
    [ "FPUStackingDisable", "group__fpu__api.html#gaef068bbfa239ba3d09e8ce33a49b8e6b", null ],
    [ "FPUStackingEnable", "group__fpu__api.html#ga8a12b01294e0670d8d4898837a1a223f", null ]
];