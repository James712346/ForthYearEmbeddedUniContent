var group__Tasks =
[
    [ "checkMotor", "group__Tasks.html#ga8d6f239da630b7b16b0e02a4aaa664f1", null ],
    [ "CreateMotorTask", "group__Tasks.html#ga17acdc6905b68b45c67aa61fe958f688", null ],
    [ "hallEffectDecode", "group__Tasks.html#ga988a20ffdf02ddb5e1df3a83828494aa", null ],
    [ "PIController", "group__Tasks.html#ga445c1fe9e799900b7cf8ed61daaca680", null ],
    [ "print_double", "group__Tasks.html#ga0f17f0feb738a5df7e0d799970259e06", null ],
    [ "RPMCalculate", "group__Tasks.html#ga116fdd93b02eab3cdc08b91546ea4048", null ],
    [ "startMotor", "group__Tasks.html#ga38e4b9838f7dc595ffb571461204365b", null ]
];