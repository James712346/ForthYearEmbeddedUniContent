var group__bmi160ApiData =
[
    [ "bmi160_get_sensor_data", "group__bmi160ApiData.html#bmi160_api_bmi160_get_sensor_data", null ]
];