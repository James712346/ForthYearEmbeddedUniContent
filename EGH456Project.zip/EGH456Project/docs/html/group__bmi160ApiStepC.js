var group__bmi160ApiStepC =
[
    [ "bmi160_set_step_counter", "group__bmi160ApiStepC.html#bmi160_api_bmi160_set_step_counter", null ],
    [ "bmi160_read_step_counter", "group__bmi160ApiStepC.html#bmi160_api_bmi160_read_step_counter", null ]
];