var group__interrupt__api =
[
    [ "NUM_INTERRUPTS", "group__interrupt__api.html#ga8b9ae71d2ea53a231841b41414acf1ec", null ],
    [ "IntDisable", "group__interrupt__api.html#ga9af6b00884dc44e92b3d05ff821b5334", null ],
    [ "IntEnable", "group__interrupt__api.html#ga49fc9c3d1a0f8c42a20249f8c5d360ce", null ],
    [ "IntIsEnabled", "group__interrupt__api.html#ga2c8b044169061f80ea2a2d11af591d18", null ],
    [ "IntMasterDisable", "group__interrupt__api.html#gae3724c6b65b8461cf0441f09b13fadf5", null ],
    [ "IntPendClear", "group__interrupt__api.html#gab708e168ca0f1f554bb141e5b0fd1bdc", null ],
    [ "IntPendSet", "group__interrupt__api.html#gafe17b56764bff1bcb95bd53acde4ac98", null ],
    [ "IntPriorityGet", "group__interrupt__api.html#gac6a7849e23f4a84c1bcaad2e9bcc27b2", null ],
    [ "IntPriorityGroupingGet", "group__interrupt__api.html#ga86595146bc7ea51280d5abbb45fcf02a", null ],
    [ "IntPriorityGroupingSet", "group__interrupt__api.html#ga341c2244311b2c8c84b0a5546fc3dff1", null ],
    [ "IntPriorityMaskGet", "group__interrupt__api.html#gad39b7d4927274abf42c57767218af279", null ],
    [ "IntPriorityMaskSet", "group__interrupt__api.html#ga61b8f34d64c588f632509406b50e4f68", null ],
    [ "IntPrioritySet", "group__interrupt__api.html#ga0432ddf52557352ac987f7dd211c2017", null ],
    [ "IntRegister", "group__interrupt__api.html#ga0a32aafea7f4904d2a64ee18b45f96c9", null ],
    [ "IntTrigger", "group__interrupt__api.html#ga374a8725d31b31ed8f10b1609fe05f64", null ],
    [ "IntUnregister", "group__interrupt__api.html#ga5dffc81c27c005f83e9bfc30f775982a", null ]
];