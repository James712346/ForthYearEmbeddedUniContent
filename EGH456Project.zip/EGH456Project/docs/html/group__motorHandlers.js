var group__motorHandlers =
[
    [ "xGPIOHandlerH", "group__motorHandlers.html#gafcf62509553f63c5a7bf44e7d61c960b", null ],
    [ "xGPIOHandlerM", "group__motorHandlers.html#gaf3d16f19c3510a10f87fc0bcf1e57918", null ],
    [ "xGPIOHandlerN", "group__motorHandlers.html#gab522aa5b63f839693f4c5f1da54dde72", null ]
];