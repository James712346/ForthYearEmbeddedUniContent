var group__sensor =
[
    [ "bmi160_delay_ms", "group__sensor.html#ga3db71e0c6f76ba9d836b729cb72debf3", null ],
    [ "bmi160_i2c_read", "group__sensor.html#gaa1d5db0b78dfce4d313f109cf35fa084", null ],
    [ "bmi160_i2c_write", "group__sensor.html#ga5f5c6dfb34e8984a418f157796a65acc", null ],
    [ "I2C2IntHandler", "group__sensor.html#ga21bbeb5d498eb3c586eed3438346602c", null ],
    [ "sht31_read_temperature_humidity", "group__sensor.html#gae10fc24fb8a9b2c2c93680af41a15f6f", null ],
    [ "sht31_task", "group__sensor.html#gad9feeb37626caf779d5dfd155187a077", null ],
    [ "humiData", "group__sensor.html#gab96c691c30f1206e1c873354bd4605c8", null ],
    [ "lightData", "group__sensor.html#ga96d3534f6fb02a53ca48cf470226454c", null ],
    [ "tempData", "group__sensor.html#ga37893f9ea6e704202da1394efc116acc", null ],
    [ "xI2CSemaphore", "group__sensor.html#gadbbad82036b51b16678901d769122ba3", null ]
];