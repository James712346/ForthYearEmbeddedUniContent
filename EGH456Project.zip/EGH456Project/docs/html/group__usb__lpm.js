var group__usb__lpm =
[
    [ "USBDevLPMConfig", "group__usb__lpm.html#ga5c0c08c6d3c193f6db2eda268b46dc42", null ],
    [ "USBDevLPMDisable", "group__usb__lpm.html#ga4b59342a0637a1760e907f0ba8d7fb0b", null ],
    [ "USBDevLPMEnable", "group__usb__lpm.html#ga2b9bf534386fa02ad13b0ada5e9d822a", null ],
    [ "USBDevLPMRemoteWake", "group__usb__lpm.html#ga092f417e2a297be6e426aa3ecfb63615", null ],
    [ "USBHostLPMConfig", "group__usb__lpm.html#gab2da4122a53a783a3bdd447a3f5f4eec", null ],
    [ "USBHostLPMResume", "group__usb__lpm.html#gaf40115d2a71ba29bb764721105d07711", null ],
    [ "USBHostLPMSend", "group__usb__lpm.html#ga93fca23ee70d3c315aad72edb35a71d5", null ],
    [ "USBLPMEndpointGet", "group__usb__lpm.html#ga0df1f20eccf05dc7c7b46f8b30467d83", null ],
    [ "USBLPMIntDisable", "group__usb__lpm.html#gaff597fd519bd421030a7bdcf401a335b", null ],
    [ "USBLPMIntEnable", "group__usb__lpm.html#gabf62f681f8c921f40458b10997e7e527", null ],
    [ "USBLPMIntStatus", "group__usb__lpm.html#ga87c3f4c04d94b649bdeea78b73abdddf", null ],
    [ "USBLPMLinkStateGet", "group__usb__lpm.html#ga87af42a42cd5926ba7bd8a82946ebf9c", null ],
    [ "USBLPMRemoteWakeEnabled", "group__usb__lpm.html#ga56ea1183888f99d9b9b6e6660821bfa9", null ]
];