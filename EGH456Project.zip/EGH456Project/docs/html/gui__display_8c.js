var gui__display_8c =
[
    [ "GUI_AddDataPoint", "group__gui.html#ga7e1d73815f1971736537b8008750f7dc", null ],
    [ "GUI_DrawGraph", "group__gui.html#gad793ea89e792020a046a5b87854ac8f9", null ],
    [ "GUI_SetActivePlot", "group__gui.html#gac2756168cc0646a78f2968c7e24b373e", null ],
    [ "OnResetZoom", "group__gui.html#gaa71aad44c227cd8d7a6bad2f0577fec5", null ],
    [ "OnZoomIn", "group__gui.html#ga8a8f60d14a154ca3d5a1494cb37403ad", null ],
    [ "OnZoomOut", "group__gui.html#ga3d95419a5794bc1f3aaeff25e758295c", null ],
    [ "g_bPlotVisible", "group__gui.html#ga94a30ea2ab67d3ed250f422a6fab3c22", null ],
    [ "g_currentPlot", "group__gui.html#ga5eeb95f8193572d511ea9833d4bcd249", null ],
    [ "g_plotUnitText", "group__gui.html#ga5c8a6b3b5912ab23789b7ec9d6a6bf0a", null ],
    [ "g_sPlotArea", "group__gui.html#gafa51cf8b672c949961e6713dd9087269", null ]
];