var opt3001_8h =
[
    [ "sensorOpt3001Convert", "opt3001_8h.html#a1a39999158a044998a259d6dbd5b8efb", null ],
    [ "sensorOpt3001Enable", "opt3001_8h.html#ac69ae5d241fa977705b64928862823e0", null ],
    [ "sensorOpt3001Init", "opt3001_8h.html#abda5e71d89c3d11303592cbf252e11ef", null ],
    [ "sensorOpt3001Read", "opt3001_8h.html#ac7bead683f0a679b1d3bebf201d77d84", null ],
    [ "sensorOpt3001Test", "opt3001_8h.html#a134170b954470c3b910e6ddba41e0dd2", null ]
];