var structGraphSample =
[
    [ "value", "structGraphSample.html#a569b52a6494e72f93c99602e87dcb3dd", null ]
];