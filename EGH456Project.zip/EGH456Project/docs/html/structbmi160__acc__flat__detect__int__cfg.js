var structbmi160__acc__flat__detect__int__cfg =
[
    [ "flat_en", "structbmi160__acc__flat__detect__int__cfg.html#aba6c29da8edf459cf4e7c0959a4d4134", null ],
    [ "flat_hold_time", "structbmi160__acc__flat__detect__int__cfg.html#a40f12717379ce903f27a9a71f276b615", null ],
    [ "flat_hy", "structbmi160__acc__flat__detect__int__cfg.html#a12d9e2313abcf20d7aef943754ed2ed0", null ],
    [ "flat_theta", "structbmi160__acc__flat__detect__int__cfg.html#afe2e549538648ec44b131154a8363b78", null ]
];