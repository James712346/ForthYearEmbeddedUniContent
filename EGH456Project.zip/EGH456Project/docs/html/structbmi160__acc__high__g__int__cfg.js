var structbmi160__acc__high__g__int__cfg =
[
    [ "high_data_src", "structbmi160__acc__high__g__int__cfg.html#a7f031ec023abd4a52e3e2021174c5b4d", null ],
    [ "high_dur", "structbmi160__acc__high__g__int__cfg.html#a2feccf7247bc054d5357648b3b7deb34", null ],
    [ "high_g_x", "structbmi160__acc__high__g__int__cfg.html#ac5d2787720023addfa237d6686a1349f", null ],
    [ "high_g_y", "structbmi160__acc__high__g__int__cfg.html#a10479c317ad5978a56bf5ebf9c5be6c2", null ],
    [ "high_g_z", "structbmi160__acc__high__g__int__cfg.html#a7c91a2ae708e52ceb21db9674f2fcef0", null ],
    [ "high_hy", "structbmi160__acc__high__g__int__cfg.html#a8283eb590b9061618109e67ed907da5f", null ],
    [ "high_thres", "structbmi160__acc__high__g__int__cfg.html#afa7eda8fc658568816b364c5db359ed1", null ]
];