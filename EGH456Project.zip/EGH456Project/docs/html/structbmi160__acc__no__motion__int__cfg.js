var structbmi160__acc__no__motion__int__cfg =
[
    [ "no_motion_dur", "structbmi160__acc__no__motion__int__cfg.html#a8d30e15605e53024e4d0014ad3b3e52b", null ],
    [ "no_motion_sel", "structbmi160__acc__no__motion__int__cfg.html#a903d70d4a34b4b7f419282f44a55673f", null ],
    [ "no_motion_src", "structbmi160__acc__no__motion__int__cfg.html#a91300c2f75a709aa39b4511e2e8cfbfa", null ],
    [ "no_motion_thres", "structbmi160__acc__no__motion__int__cfg.html#a9461d2c02af85ea1c4e194ac891a9bfe", null ],
    [ "no_motion_x", "structbmi160__acc__no__motion__int__cfg.html#ac68b1068928beaf952bfa2239d46ae44", null ],
    [ "no_motion_y", "structbmi160__acc__no__motion__int__cfg.html#aee03728b0de14a9a14f95e5694fe25c6", null ],
    [ "no_motion_z", "structbmi160__acc__no__motion__int__cfg.html#abe2f88d71e433482545b9eea69e70425", null ]
];