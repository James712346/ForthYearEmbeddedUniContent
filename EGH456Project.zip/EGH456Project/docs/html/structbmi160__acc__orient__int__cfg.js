var structbmi160__acc__orient__int__cfg =
[
    [ "axes_ex", "structbmi160__acc__orient__int__cfg.html#a908f04ab7f11a41ba821c6d6e4467c1c", null ],
    [ "orient_blocking", "structbmi160__acc__orient__int__cfg.html#ab4c2419a00e66125f3deef5f1cad5f14", null ],
    [ "orient_en", "structbmi160__acc__orient__int__cfg.html#ac4106c0658f3e9d9ccb03437e15f6d77", null ],
    [ "orient_hyst", "structbmi160__acc__orient__int__cfg.html#ab013457308ee7564a7c6709f397c79ae", null ],
    [ "orient_mode", "structbmi160__acc__orient__int__cfg.html#ac92ba9b915912f993248aff99063c0fa", null ],
    [ "orient_theta", "structbmi160__acc__orient__int__cfg.html#aaa695f62ad1f9b64632935169a057c5a", null ],
    [ "orient_ud_en", "structbmi160__acc__orient__int__cfg.html#a738633e81db553e6a3dc5881122e8b1e", null ]
];