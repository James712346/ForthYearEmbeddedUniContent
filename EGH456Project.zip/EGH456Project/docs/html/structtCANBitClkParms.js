var structtCANBitClkParms =
[
    [ "ui32Phase2Seg", "structtCANBitClkParms.html#a96b0f1b88e10ce0094155f793990067a", null ],
    [ "ui32QuantumPrescaler", "structtCANBitClkParms.html#ac92cfb9c4c199f4a86b5ffac321ebe06", null ],
    [ "ui32SJW", "structtCANBitClkParms.html#a0f39e259ea7f08df8079f67b177cbc39", null ],
    [ "ui32SyncPropPhase1Seg", "structtCANBitClkParms.html#a883e98bff1da9402389f9fcd3be2c89e", null ]
];