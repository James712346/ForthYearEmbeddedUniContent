var structtListBoxWidget =
[
    [ "i16Selected", "structtListBoxWidget.html#a4601834793ef7d7e1f1bf689a26b79b0", null ],
    [ "i32PointerY", "structtListBoxWidget.html#ab1d6b85d60fd00679223e62f5d6bba5e", null ],
    [ "pfnOnChange", "structtListBoxWidget.html#a145177998d367fd3080e1d2211df3f0c", null ],
    [ "ppcText", "structtListBoxWidget.html#ad485a73879926fa49e43bad855165ddb", null ],
    [ "psFont", "structtListBoxWidget.html#afda157d52b17df01736192746549f41c", null ],
    [ "sBase", "structtListBoxWidget.html#a1b2e0ab12ddb0be0959bec279b18d9e5", null ],
    [ "ui16MaxEntries", "structtListBoxWidget.html#abb5795395ac48b874c523012b75c6dfe", null ],
    [ "ui16OldestEntry", "structtListBoxWidget.html#a7d9d5a08d483da5ec4f78c4c9d862feb", null ],
    [ "ui16Populated", "structtListBoxWidget.html#a6ce6a931a185041e7f33f20e6383b9b5", null ],
    [ "ui16Scrolled", "structtListBoxWidget.html#a0321be44fdc37181d2c4d6b010997809", null ],
    [ "ui16StartEntry", "structtListBoxWidget.html#aaf6977eaeff3aa7145e3eac9cfc0c57b", null ],
    [ "ui32BackgroundColor", "structtListBoxWidget.html#a6d96c000cef6cf448d7444debeef8dab", null ],
    [ "ui32OutlineColor", "structtListBoxWidget.html#aff7d9ecb83e24ee54422fbc979fd0c72", null ],
    [ "ui32SelectedBackgroundColor", "structtListBoxWidget.html#aa9ea673cbd5e539570e2fbdf519a3779", null ],
    [ "ui32SelectedTextColor", "structtListBoxWidget.html#ac23d6a0ab3213f6401aece4e03348778", null ],
    [ "ui32Style", "structtListBoxWidget.html#af1cea41114bfae5fe262326f1df3f6fd", null ],
    [ "ui32TextColor", "structtListBoxWidget.html#adcf2e94db7899562cb3fbb9151d69aba", null ]
];