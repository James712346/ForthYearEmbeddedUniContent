var vl53l0x_8h =
[
    [ "VL53L0X_OUT_OF_RANGE", "vl53l0x_8h.html#afdcbc158e68afbebdc7da7c86ae7d52b", null ],
    [ "vl53l0x_idx_t", "vl53l0x_8h.html#adde86a04bc2a682478d87c63b3df5583", [
      [ "VL53L0X_IDX_FIRST", "vl53l0x_8h.html#adde86a04bc2a682478d87c63b3df5583afae1ce54164ce41de5e5e9b956908191", null ]
    ] ],
    [ "vl53l0x_init", "vl53l0x_8h.html#ab0a1b5050c3094045382f00ca60b11e7", null ],
    [ "vl53l0x_read_range_single", "vl53l0x_8h.html#aea5fd7be09ab37bfa00378f22c488f2d", null ]
];